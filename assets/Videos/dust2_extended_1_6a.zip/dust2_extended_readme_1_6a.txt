RMF was based from 17's Buddies, DaveJ, and MacMan. I simply made certain areas accessible.

Do not modify or redistribute this map without my permission.

-- Update --
----------------------------
 1.6a - July 22, 2019
----------------------------

- Add debris near window crate
- Moved window crates slightly higher
- Switch from GLOW to LGH, and set to 'texture'
- Brighten up tunnel's light entities
- Bomb site B, use Dust 2 marker, instead of decal
- Two crates, two brushes into Two crate, one brush for Bomb Site B (when entering Bomb Site B via tunnel)
- Fix Bomb Site B Tunnel Bunker windows
- Fix T-Spawn trim texture

This is basically backporting some of the Condition Zero's Dust 2 Extended work.

----------------------------
 1.6 - June 28, 2019
----------------------------

- Rework the sky boundaries (allowing VIS and no leakage)*1
- The mini-doors are now single mini-door
- Adjust clip brush boxes-window
- No longer use custom brush for the large doors, they are now just cube*2
- Fix Bomb site B rocks
- Fix internal catwalk stairs

1 - Decided to upgrade the VHE compilers to Zoners, however, it completely flop. Refused to compile. Decided to use the '98 stockier tool.
2 - This fixes one of the side doors which the bottom widens after compiled

----------------------------
 1.4 - April 12, 2019
----------------------------

- Create an opening on catwalk near the boxes
- Replace Bomb B clip to Sky (B Main)
- Open up T-spawn sniper tunnel sky
- Fix Bomb A light tubes

----------------------------
 1.2 - Decemeber 24, 2018
----------------------------

- Fix A Long Ramp (below the A sniper nest) Light Tube
- Reduced some box size by 10-20%
- Fixed the texture for the breakable doorways
- The breakable doorways are now thinner
- Altered the T-spawn sniper wall into an arch
- Remove a sky brush on the T-spawn open arch
- Add map overview (not really accurate)


----------------------------
 1.1 - November 29, 2018
----------------------------

- The light tubes are now Constant Glow and Solid
- The light tubes are now using White texture, instead of light (not sure why it is not working)
- Fix Site A Ramp

Install - Drag and Drop de_dust2_extended.bsp/.txt inside your cstrike/maps

Contact - al-proto1995@hotmail.com